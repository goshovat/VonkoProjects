﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TradeAndTravel
{
    public class InteractionManagerExtended : InteractionManager
    {
        const int InitialPersonMoney = 100;

        protected override Item CreateItem(string itemTypeString, string itemNameString, Location itemLocation, Item item)
        {
            switch (itemTypeString)
            {
                case "armor":
                    item = new Armor(itemNameString, itemLocation);
                    break;
                case "weapon":
                    item = new Weapon(itemNameString, itemLocation);
                    break;
                case "wood":
                    item = new Wood(itemNameString, itemLocation);
                    break;
                case "iron":
                    item = new Iron(itemNameString, itemLocation);
                    break;
                default:
                    break;
            }
            return item;
        }

        protected override Location CreateLocation(string locationTypeString, string locationName)
        {
            Location location = null;
            switch (locationTypeString)
            {
                case "town":
                    location = new Town(locationName);
                    break;
                case "mine":
                    location = new Mine(locationName);
                    break;
                case "forest":
                    location = new Mine(locationName);
                    break;
                default:
                    break;
            }
            return location;
        }

        protected override void HandlePersonCommand(string[] commandWords, Person actor)
        {
            switch (commandWords[1])
            {
                case "drop":
                    HandleDropInteraction(actor);
                    break;
                case "pickup":
                    HandlePickUpInteraction(actor);
                    break;
                case "sell":
                    this.HandleSellInteraction(commandWords, actor);
                    break;
                case "buy":
                    HandleBuyInteraction(commandWords, actor);
                    break;
                case "inventory":
                    HandleListInventoryInteraction(actor);
                    break;
                case "money":
                    Console.WriteLine(moneyByPerson[actor]);
                    break;
                case "travel":
                    HandleTravelInteraction(commandWords, actor);
                    break;
                case "gather":
                    HandleGatherInteraction(commandWords, actor);
                    break;
                case "craft":
                    HandleCraftInteraction(commandWords, actor);
                    break;
                default:
                    break;
            }
        }

        protected void HandlePickUpInteraction(Person actor)
        {
            foreach (var item in strayItemsByLocation[actor.Location])
            {
                this.AddToPerson(actor, item);
                item.UpdateWithInteraction("pickup");
            }
            strayItemsByLocation[actor.Location].Clear();
        }

        protected void HandleDropInteraction(Person actor)
        {
            foreach (var item in actor.ListInventory())
            {
                if (ownerByItem[item] == actor)
                {
                    strayItemsByLocation[actor.Location].Add(item);
                    this.RemoveFromPerson(actor, item);

                    item.UpdateWithInteraction("drop");
                }
            }
        }

        protected void HandleBuyInteraction(string[] commandWords, Person actor)
        {
            Item saleItem = null;
            string saleItemName = commandWords[2];
            var buyer = personByName[commandWords[3]] as Shopkeeper;

            if (buyer != null &&
                peopleByLocation[actor.Location].Contains(buyer))
            {
                foreach (var item in buyer.ListInventory())
                {
                    if (ownerByItem[item] == buyer && saleItemName == item.Name)
                    {
                        saleItem = item;
                    }
                }

                var price = buyer.CalculateSellingPrice(saleItem);
                moneyByPerson[buyer] += price;
                moneyByPerson[actor] -= price;
                this.RemoveFromPerson(buyer, saleItem);
                this.AddToPerson(actor, saleItem);

                saleItem.UpdateWithInteraction("buy");
            }
        }

        protected void HandleSellInteraction(string[] commandWords, Person actor)
        {
            Item saleItem = null;
            string saleItemName = commandWords[2];
            foreach (var item in actor.ListInventory())
            {
                if (ownerByItem[item] == actor && saleItemName == item.Name)
                {
                    saleItem = item;
                }
            }

            var buyer = personByName[commandWords[3]] as Shopkeeper;
            if (buyer != null &&
                peopleByLocation[actor.Location].Contains(buyer))
            {
                var price = buyer.CalculateBuyingPrice(saleItem);
                moneyByPerson[buyer] -= price;
                moneyByPerson[actor] += price;
                this.RemoveFromPerson(actor, saleItem);
                this.AddToPerson(buyer, saleItem);

                saleItem.UpdateWithInteraction("sell");
            }
        }

        protected void HandleTravelInteraction(string[] commandWords, Person actor)
        {
            var traveller = actor as ITraveller;
            if (traveller != null)
            {
                var targetLocation = this.locationByName[commandWords[2]];
                peopleByLocation[traveller.Location].Remove(actor);
                traveller.TravelTo(targetLocation);
                peopleByLocation[traveller.Location].Add(actor);

                foreach (var item in actor.ListInventory())
                {
                    item.UpdateWithInteraction("travel");
                }
            }
        }

        protected void HandleListInventoryInteraction(Person actor)
        {
            var inventory = actor.ListInventory();
            foreach (var item in inventory)
            {
                if (ownerByItem[item] == actor)
                {
                    Console.WriteLine(item.Name);
                    item.UpdateWithInteraction("inventory");
                }
            }

            if (inventory.Count == 0)
            {
                Console.WriteLine("empty");
            }
        }

        protected void HandleGatherInteraction(string[] commandWords, Person actor)
        {
            //var targetLocation = actor.Location;

            //if (targetLocation != null)
            //{
            //    string newItemName = commandWords[2];

            //    if (targetLocation.LocationType == LocationType.Forest)
            //    {
            //        bool hasWeapon = false;
            //        foreach (Item item in actor.ListInventory())
            //        {
            //            if (item.ItemType == ItemType.Weapon)
            //            {
            //                hasWeapon = true;
            //                break;
            //            }
            //        }

            //        if (hasWeapon)
            //        {
            //            base.AddToPerson(actor, new Wood(newItemName));
            //        }
            //    }
            //    else if (targetLocation.LocationType == LocationType.Mine)
            //    {
            //        bool hasArmor = false;
            //        foreach (Item item in actor.ListInventory())
            //        {
            //            if (item.ItemType == ItemType.Armor)
            //            {
            //                hasArmor = true;
            //                break;
            //            }
            //        }

            //        if (hasArmor)
            //        {
            //            base.AddToPerson(actor, new Iron(newItemName));
            //        }
            //    }
            //}

            string chosenItemName = commandWords[2];
            var gatheringLocation = actor.Location as IGatheringLocation;
            if (gatheringLocation != null)
            {
                var requiredItemType = gatheringLocation.RequiredItem;
                var actorInventory = actor.ListInventory();

                bool actorHasItemType = InventoryHasItemType(requiredItemType, actorInventory);

                if (actorHasItemType)
                {
                    this.AddToPerson(actor, gatheringLocation.ProduceItem(chosenItemName));
                }
            }
        }

        protected void HandleCraftInteraction(string[] commandWords, Person actor)
        {
            string itemTypeToCraft = commandWords[2];
            string chosenItemName = commandWords[3];
            var actorInventory = actor.ListInventory();
            if (itemTypeToCraft == "armor")
            {
                if (InventoryHasItemType(ItemType.Iron, actorInventory))
                {
                    AddToPerson(actor, new Armor(chosenItemName));
                }
            }
            else if (itemTypeToCraft == "weapon")
            {
                if (InventoryHasItemType(ItemType.Iron, actorInventory) &&
                    InventoryHasItemType(ItemType.Wood, actorInventory))
                {
                    AddToPerson(actor, new Weapon(chosenItemName));
                }
            }
        }

        protected override void HandlePersonCreation(string personTypeString, string personNameString, string personLocationString)
        {
            var personLocation = locationByName[personLocationString];

            Person person = CreatePerson(personTypeString, personNameString, personLocation);

            personByName[personNameString] = person;
            peopleByLocation[personLocation].Add(person);
            moneyByPerson[person] = InteractionManagerExtended.InitialPersonMoney;
        }

        protected override Person CreatePerson(string personTypeString, string personNameString, Location personLocation)
        {
            Person person = null;
            switch (personTypeString)
            {
                case "shopkeeper":
                    person = new Shopkeeper(personNameString, personLocation);
                    break;
                case "traveller":
                    person = new Traveller(personNameString, personLocation);
                    break;
                case "merchant":
                    person = new Merchant(personNameString, personLocation);
                    break;
                default:
                    break;
            }
            return person;
        }

        private static bool InventoryHasItemType(ItemType requiredItemType, List<Item> actorInventory)
        {
            bool actorHasItemType = false;
            foreach (var item in actorInventory)
            {
                if (item.ItemType == requiredItemType)
                {
                    actorHasItemType = true;
                    break;
                }
            }
            return actorHasItemType;
        }
    }
}
